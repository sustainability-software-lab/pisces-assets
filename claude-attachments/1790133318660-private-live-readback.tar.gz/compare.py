import base64,gzip,hashlib,json,pathlib,tarfile,collections,math
ROOT=pathlib.Path(__file__).resolve().parents[2]
OUT=pathlib.Path(__file__).resolve().parent
with tarfile.open(ROOT/'research/watertap-import/campaign-2026-09-17/watertap-review-v8.tar.xz') as t: originals=json.load(t.extractfile('pisces-qa/campaign-documents.json'))
historical={r['sffData']['metadata']['registry_key']:r['sffData'] for r in originals}
def native_id(s):
 w=s['_watertap'];return w.get('path') or w.get('source_path') or ('boundary.'+w['port'] if 'port' in w else 'quantity.'+w['native_quantity'])
def differences(a,b,path=''):
 if isinstance(a,dict) and isinstance(b,dict):
  for k in sorted(a.keys()|b.keys()):
   if k not in a or k not in b:yield {'path':path+'/'+k,'kind':'missing_field'}
   else:yield from differences(a[k],b[k],path+'/'+k)
 elif isinstance(a,list) and isinstance(b,list):
  if len(a)!=len(b):yield {'path':path,'kind':'length_change','before':len(a),'after':len(b)}
  else:
   for i,(aa,bb) in enumerate(zip(a,b)):yield from differences(aa,bb,path+'/'+str(i))
 elif a!=b:
  numeric=type(a) in (int,float) and type(b) in (int,float) and math.isfinite(a) and math.isfinite(b)
  yield {'path':path,'kind':'numeric' if numeric else 'other','before':a,'after':b,**({'absoluteDelta':abs(a-b),'relativeDelta':abs(a-b)/max(abs(a),abs(b)) if a or b else 0} if numeric else {})}
rows=[]; totals=collections.Counter()
for file in sorted(OUT.glob('sff-*.json')):
 response=json.loads(file.read_text());d=response['sffData'];key=d['metadata']['registry_key'];h=historical[key]
 w=d['metadata']['_watertap'];old=h['metadata']['_watertap'];blob=w['native_evidence'];raw=gzip.decompress(base64.b64decode(blob['content']))
 assert len(raw)==blob['uncompressed_bytes'] and hashlib.sha256(raw).hexdigest()==blob['uncompressed_sha256']
 streamrows=[];oldstreams={native_id(s):s for s in h['streams']}; liveunits={u['id']:native_id(u) for u in d['units']}
 for s in d['streams']:
  oldstream=oldstreams[native_id(s)];props=s.get('stream_properties',{})
  checks={k:s.get(k)==oldstream.get(k) for k in ['_watertap','composition','stream_properties']}
  delta=[change for k in ['_watertap','composition','stream_properties'] for change in differences(oldstream.get(k),s.get(k),k)]
  checks.update({k:liveunits.get(s.get(k),s.get(k))==oldstream.get(k) for k in ['source_unit_id','sink_unit_id']})
  streamrows.append({'id':s['id'],'nativeId':native_id(s),'historicalScientificFieldsEqual':all(checks.values()),'fieldEquality':checks,'scientificDifferences':delta,'fieldsPresent':list(props),'compositionCount':len(s.get('composition',[]))})
  totals['streams']+=1
  for f in ['total_mass_flow','total_molar_flow','total_volumetric_flow']:totals[f]+=f in props
  totals['composition']+=bool(s.get('composition'))
 row={'registryKey':key,'id':response['id'],'numericId':response['numericId'],'sourceType':response['sourceType'],'ownerCorrect':response['userId']=='cmme7ofk60000s60e20yxk0i3','private':response['isPublic'] is False,'visibility':response['visibility'],'publicationStatus':response['publicationStatus'],'validationStatus':response['validationStatus'],'solutionState':response['solutionState'],'sourceUrl':d['metadata'].get('source_url'),'nativeHashValid':True,'nativeEnvelopeEqualsHistorical':blob==old['native_evidence'],'sourceEqualsHistorical':w['source']==old['source'],'entrypointEqualsHistorical':w['entrypoint_source']==old['entrypoint_source'],'chemicalsEqualsHistorical':d.get('chemicals',[])==h.get('chemicals',[]),'sameNativeStreamIds':set(oldstreams)=={native_id(s) for s in d['streams']},'sameNativeUnitIds':{native_id(u) for u in h['units']}=={native_id(u) for u in d['units']},'streamScientificFieldsEqual':all(s['historicalScientificFieldsEqual'] for s in streamrows),'qualification':w.get('qualification'),'streams':streamrows}
 rows.append(row)
assert len(rows)==29 and {r['registryKey'] for r in rows}==set(historical)
deltas=[x for r in rows for stream in r['streams'] for x in stream['scientificDifferences']]
summary={key:sum(bool(r[key]) for r in rows) for key in ['ownerCorrect','private','nativeHashValid','nativeEnvelopeEqualsHistorical','sourceEqualsHistorical','entrypointEqualsHistorical','chemicalsEqualsHistorical','sameNativeStreamIds','sameNativeUnitIds','streamScientificFieldsEqual']}
report={'scope':'Fresh production GET audit, no mutations','observedAt':json.loads((OUT/'corpus-read-receipt.json').read_text())['finishedAt'],'denominator':29,'historicalArchiveSha256':'a7acc1977f2b6f7aa7ce73f06da9863630aa2324c0b08f9ef4f64d6aa6ea3c8a','summary':summary,'scientificDifferences':{'count':len(deltas),'kinds':dict(collections.Counter(x['kind'] for x in deltas)),'maxRelativeNumericDelta':max((x.get('relativeDelta',0) for x in deltas),default=0),'maxAbsoluteNumericDelta':max((x.get('absoluteDelta',0) for x in deltas),default=0)},'streamTotals':dict(totals),'sourceTypes':dict(collections.Counter(r['sourceType'] for r in rows)),'states':dict(collections.Counter(r['solutionState'] for r in rows)),'publicationStatuses':dict(collections.Counter(r['publicationStatus'] for r in rows)),'models':rows}
(OUT/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='models'},indent=2))
